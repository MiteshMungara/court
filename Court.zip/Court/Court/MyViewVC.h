//
//  MyViewVC.h
//  Court
//
//  Created by iSquare infoTech on 1/31/17.
//  Copyright © 2017 MitsSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyViewVC : UIViewController
@property(strong,nonatomic) UILabel *mapTitleLabel;
@end
