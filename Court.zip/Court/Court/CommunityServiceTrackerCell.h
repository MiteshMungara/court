//
//  CommunityServiceTrackerCell.h
//  Court
//
//  Created by iSquare infoTech on 1/28/17.
//  Copyright © 2017 MitsSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommunityServiceTrackerCell : UITableViewCell

@property(strong,nonatomic) IBOutlet UILabel *namecommunitieslbl, *timecommunitylbl;
@property (strong,nonatomic) IBOutlet UIView *cellbgview;
@end
