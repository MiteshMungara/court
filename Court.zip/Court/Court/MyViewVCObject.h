//
//  MyViewVCObject.h
//  Court
//
//  Created by iSquare infoTech on 1/31/17.
//  Copyright © 2017 MitsSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyViewVCObject : NSObject

@property(strong,nonatomic) NSString *nameLabel;
@end
